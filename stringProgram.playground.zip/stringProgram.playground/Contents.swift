import UIKit

var str = "yash"
var ch,ch1,ch2:Character
var count : Int = 0
for ch in str {
    count = 0
    for ch1 in str{
        if(ch == ch1){
            count += 1}
            if(count == 2){
                print("The first repeating character is \(ch)")
                break
            }
        
        }
    if(count <= 1){
        continue
    }
    else{ break }
    }
if(count < 2) {
    print("No character is repeating")
}

