import UIKit
import Foundation

var first = 0
var second = 1
var third:Int
print(first)
print(second)
for _ in 1...10 {
   third = first + second
   print(third)
   first = second
    second = third
}
